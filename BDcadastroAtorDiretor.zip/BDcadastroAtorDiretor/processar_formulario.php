<?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexão com o banco de dados MySQL
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "form";

    $conn = new mysqli($servername, $username, $password, $dbname);
    // Verifica a conexão
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Obtém os dados do formulário
    $nome = $_POST["nome"];
    $biografia = $_POST["biografia"];
    $ocupacao = $_POST["ocupacao"];

    // Verifica se o nome já existe no banco de dados
    $sql_verificar = "SELECT COUNT(*) as total FROM opcoes WHERE nome = '$nome'";
    $result_verificar = $conn->query($sql_verificar);

    if ($result_verificar && $result_verificar->num_rows > 0) {
        $row = $result_verificar->fetch_assoc();
        $total_registros = $row['total'];

        if ($total_registros > 0) {
            // Nome já existe, redireciona para a página de confirmação com aviso
            header("Location: registro_inserido.php?nome_existente=true");
            exit();
        } else {
            // Nome não existe, proceda com a inserção
            $sql_inserir = "INSERT INTO opcoes (nome, biografia, ocupacao) VALUES ('$nome', '$biografia', '$ocupacao')";
            
            if ($conn->query($sql_inserir) === TRUE) {
                // Registro inserido com sucesso, redireciona para a página de confirmação
                header("Location: registro_inserido.php");
                exit();
            } else {
                echo "Erro ao inserir registro: " . $conn->error;
            }
        }
    } else {
        echo "Erro ao verificar o nome no banco de dados: " . $conn->error;
    }

    // Fecha a conexão com o banco de dados
    $conn->close();
}
?>
