<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Form</title>
<link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
    <div class="form">
        <h1 class="text">Cadastro</h1>
        <form method="POST" action="processar_formulario.php">
            <div class="nome">
                <input type="text" name="nome" placeholder="Nome" required>
            </div>
            <div class="biografia">
                <textarea name="biografia" placeholder="Biografia" id="biografia" required></textarea>
            </div>
            <div class="alternancia">
                <input type="radio" id="ator" name="ocupacao" value="ator">
                <label for="ator">Ator</label>
                <input type="radio" id="diretor" name="ocupacao" value="diretor">
                <label for="diretor">Diretor</label>
            </div>
            <button type="submit" class="botao">Enviar</button>
        </form>
    </div>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Processar os dados do formulário aqui
        $nome = $_POST['nome'];
        $biografia = $_POST['biografia'];
        $ocupacao = $_POST['ocupacao'];
        echo "<p>Dados recebidos:<br>Nome: $nome<br>Biografia: $biografia<br>Ocupação: $ocupacao</p>";
    }
    ?>
</body>
</html>
