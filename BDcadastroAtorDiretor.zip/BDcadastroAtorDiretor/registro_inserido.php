<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registro Inserido</title>
<link rel="stylesheet" type="text/css" href="/css/registro.css">
</head>
<body>
    <div class="container">
        <div class="box">
            <?php
            // Verifica se o nome já existe
            if (isset($_GET['nome_existente']) && $_GET['nome_existente'] == 'true') {
                echo '<h2>Erro ao Inserir Registro</h2>';
                echo '<p>O nome já existe no banco de dados.</p>';
            } else {
                echo '<h2>Registro Inserido com Sucesso!</h2>';
                echo '<p>Seu registro foi enviado com sucesso.</p>';
            }
            ?>
            <a href="javascript:history.go(-1)" class="btn">Voltar</a>
        </div>
    </div>
</body>
</html>
